var app = {};

// набор изменений
app.Commit = Backbone.Model.extend({
  
  idAttribute: "commit",

  defaults: {
    user:    "",
    date:    "",
    comment: "",
    items:   [],
    commit:  null
  },

  url: function(){
    if ( !this.get("commit") ) throw "No commit number defiend";
    return "/changeset/" + this.get("commit");
  }

});

var Commits = Backbone.Collection.extend({
  model: app.Commit
});
app.Commits = new Commits();

app.AppView = Backbone.View.extend({

  el: ".main-container",

  events: {
    "click [action=getCommit]":   "getCommit",
    "click [action=removeItems]": "removeItems",
    "keyup #commit":              "checkCommit",
    "blur  #commit":              "checkCommit",
    "keyup #label":               "checkLabel",
    "blur  #label":               "checkLabel",
    "click [action=labelItems]":  "labelItems"
  },

  initialize: function(){
    this.$commitInput  = $( "input[name=commit]"  );
    this.$commitButton = $( "[action=getCommit]"  );
    this.$labelInput   = $( "input[name=label]"   );
    this.$labelButton  = $( "[action=labelItems]" );
    this.$commentInput = $( "input[name=comment]" );
    this.$table        = $( "#table" );

    this.listenTo( app.Commits, 'add', this.addCommitItems );

    var dateFormatter = function(date, zeros){
      function padZero(x,z){ return x.toString().padStart(z||1,'0') };
      return padZero(date.getFullYear(),4) + '/' + padZero(date.getMonth(),  2) + '/' + padZero(date.getDate(),   2) + ' ' + 
             padZero(date.getHours()   ,2) + ':' + padZero(date.getMinutes(),2) + ':' + padZero(date.getSeconds(),2) + '.' + 
             padZero(date.getMilliseconds(),3)
    };

    this.$table.bootstrapTable({
      search: true,
      clickToSelect: true,
      columns: [
        { field: 'selected', title: 'Выбран?',  checkbox: true  }, 
        { field: 'commit',   title: 'Коммит',   sortable: true  }, 
        { field: 'folder',   title: 'Папка',    sortable: true  }, 
        { field: 'name',     title: 'Элемент',  sortable: true  },
        { field: 'date',     title: 'Время',    sortable: true, formatter: dateFormatter },
        { field: 'action',   title: 'Действие', sortable: true  },
      ]
    });

    this.$labelInput.autocomplete({
      source: this.loadLabelNames()
    });
  },

  getCommit: function(){

    var commitNumberCheck = this.checkCommit();
    if ( commitNumberCheck ){  alert( commitNumberCheck ); return;  };

    var commitNumber = this.$commitInput.val();
    if ( commitNumber && parseInt(commitNumber) ){
      var commit = new app.Commit({ commit: parseInt(commitNumber) });

      commit.fetch()
            .done( function( data, textStatus, jqXHR ){
              app.Commits.add( commit );
            });

    };
  },

  addCommitItems: function( commit ){

    this.$table.bootstrapTable('append', 
      commit.get("items")
            .map( function(item){
              return {
                folder:   item["folder"], 
                fullname: item["fullname"], 
                name:     item["name"], 
                type:     item["type"], 
                action:   item["action"], 
                commit:   commit.get("commit"),
                date:     new Date(commit.get("date")),
                selected: false
              };
            })
    );
  },

  removeItems: function(){
    app.Commits.reset([]);
    this.$table.bootstrapTable('removeAll');
  },


  labelItems: function(){

      var labelNameCheck = this.checkLabel();
      var selectionCheck = this.checkSelections();
      
      if ( labelNameCheck ){  alert( labelNameCheck ); return;  };
      if ( selectionCheck ){  alert( selectionCheck ); return;  };

      var labelName  = this.$labelInput.val();
      var selections = this.$table.bootstrapTable('getSelections');

      this.saveLabelName(labelName);
      
      var commits = {};
      selections.forEach( function(selection){
        commits[ selection["fullname"] ] = selection["commit"]
      });

      var comment = this.$commentInput.val();
      $.post(
        "/label/" + encodeURIComponent(labelName), 
        { files: JSON.stringify( commits ), comment: comment },
        function(data, textStatus, jqXHR){ 
          console.log( data, textStatus, jqXHR );
        }
      )
  },

  checkCommit: function( ){
      var commitNumber = this.$commitInput.val();
      if ( commitNumber && parseInt(commitNumber) ){
          this.$commitButton.attr({disabled: false});
      } else {
          this.$commitButton.attr({disabled: true});
          return "Enter a commit number!";
      };
  },
  checkLabel: function(){
      var labelName = this.$labelInput.val();
      if ( labelName ){
          this.$labelButton.attr({disabled: false});
      } else {
          this.$labelButton.attr({disabled: true});
          return "Enter a label name!";
      }
  },
  checkSelections: function(selections){
      var selections = this.$table.bootstrapTable('getSelections');
      if ( selections.length === 0 ) return "Choose files!";
  },

  saveLabelName: function(labelName){
      var localLabels = JSON.parse( localStorage.getItem("labels") || "[]" );
      if ( localLabels.indexOf(labelName) == -1 ){
        localStorage.setItem("labels", JSON.stringify( localLabels.concat(labelName) ) );
      };
  },
  loadLabelNames: function(){
      return JSON.parse( localStorage.getItem("labels") || "[]" );
  }

});

var ENTER_KEY = 13;
$(function() {
    new app.AppView();
});