var app = {};

// элементы из набора изменений
app.Item = Backbone.Model.extend({
  
  defaults: {
    folder:   "",
    fullname: "",
    name:     "",
    type:     "",
    action:   "",
    commit:   null,
    date:     null,
    selected: false
  },

  toggle: function(){
    this.save({
      selected: !this.get("selected")
    })
  }

});

// набор изменений
app.Commit = Backbone.Model.extend({
  
  idAttribute: "commit",

  defaults: {
    user:    "",
    date:    "",
    comment: "",
    items:   [],
    commit:  null
  },

  url: function(){
    if ( !this.get("commit") ) throw "No commit number defiend";
    return "/changeset/" + this.get("commit");
  }

});

// коллекция наборов изменений
var Items = Backbone.Collection.extend({

  model: app.Item,

  selected: function(){
    return this.filter(function( item ){
      return this.get("selected")
    });
  },

  nextOrder: function(){
    if ( this.length ) return this.last().get("order") + 1;
    else               return 1;
  },

  comparator: function( item ){
    return +this.get("commit");
  }

});
app.Items = new Items();

app.AppView = Backbone.View.extend({

  el: "#container",

  events: {
    "click [action=getCommit]":   "getCommit",
    "click [action=removeItems]": "removeItems"
  },

  initialize: function(){
    this.$commitInput = $( "input[name=commit]" );
    this.$labelInput  = $( "input[name=label]"  );
    
    this.listenTo( app.Items, 'add',   this.addOne);
    this.listenTo( app.Items, 'reset', this.addAll);
  },

  addOne: function( item ){
    var view = app.ItemView({ model: item });
  },

  addAll: function(){
    this.$el.html('');
    app.Items.each( this.addOne, this );
  },

  getCommit: function(){
    console.log("hello");
    console.log( this.$commitInput.val() );
  },

  removeItems: function(){}

});

var ENTER_KEY = 13;
$(function() {
    new app.AppView();
});