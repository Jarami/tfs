//includes 
if (!String.prototype.includes) {
  String.prototype.includes = function(search, start) {
    'use strict';
    if (typeof start !== 'number') {
      start = 0;
    }

    if (start + search.length > this.length) {
      return false;
    } else {
      return this.indexOf(search, start) !== -1;
    }
  };
}

// closest polyfill
if (window.Element && !Element.prototype.closest) {
    Element.prototype.closest = 
    function(s) {
        var matches = (this.document || this.ownerDocument).querySelectorAll(s),
            i,
            el = this;
        do {
            i = matches.length;
            while (--i >= 0 && matches.item(i) !== el) {};
        } while ((i < 0) && (el = el.parentElement)); 
        return el;
    };
}
if (window.Element && !Element.prototype.matches) {
    Element.prototype.matches = 
        Element.prototype.matchesSelector || 
        Element.prototype.mozMatchesSelector ||
        Element.prototype.msMatchesSelector || 
        Element.prototype.oMatchesSelector || 
        Element.prototype.webkitMatchesSelector ||
        function(s) {
            var matches = (this.document || this.ownerDocument).querySelectorAll(s),
                i = matches.length;
            while (--i >= 0 && matches.item(i) !== this) {}
            return i > -1;            
        };
}

function Console1(){
  this.log = function(){
    for(i=0; i<arguments.length; i++) document.body.appendChild(document.createComment("[INFO] " + arguments[i].toString()));
  }
  this.error = function(){
    for(i=0; i<arguments.length; i++) document.body.appendChild(document.createComment("[ERROR] " + arguments[i].toString()));
  }
}
window.console1 = new Console1

function formatDate(date){

  return date.toISOString().replace("T", " ").replace(/\.\d{3}Z/, "");
  // function addZero(v){
  //   return v>9 ? ""+v : "0"+v;
  // };

  // var y = date.getFullYear(),
  //     m = addZero(date.getMonth() + 1),
  //     d = addZero(date.getDate()),
  //     hh = addZero(date.getHours()),
  //     mm = addZero(date.getMinutes()),
  //     ss = addZero(date.getSeconds());

  // return "" + y + "-" + m + "-" + d + " " + 
};

var logger = {
  _log: function(message, level, parent){
    var parent = parent || output.querySelector("ul");
    if ( typeof message === "object" ){
        
        for(var key in message){
          var li = this._log(key, level, parent);

          var ul = document.createElement("UL");
          for(var i=0; i<message[key].length; i++){
            this._log(message[key][i], level, ul);
          }
          li.appendChild(ul);
        }

    } else {
        var li = document.createElement("LI");
        li.classList.add(level);
        li.textContent = message.toString();
        parent.appendChild(li);
        return li
    }
  },
  info: function log(message){
    for(var i=0; i<arguments.length; i++) this._log(arguments[i], "info"); 
  },
  error: function error(){
    for(var i=0; i<arguments.length; i++) this._log(arguments[i], "info"); 
  }
}
function _log(message, level){
    li = document.createElement("LI");
    li.classList.add(level);
    li.textContent = arguments[i].toString();
    output.querySelector("ul").appendChild(li);
}

function View(model){
  var fileList = document.getElementById("file-list");
  var changeset = document.getElementById("changeset");
  var label = document.getElementById("label");
  var labelFilesButton = document.querySelector('button[action="label-files"]')
  
  var tbody = fileList.querySelector("tbody")
  
  var fileAccount={}, files, i;
  this.notify = function(){
    fileAccount = {};
    files = model.getFileList();
    files.forEach(function(file,index){
      file["index"] = index;
      fileAccount[index.toString()] = file;
    })
    draw(files);
  };
  
  this.getChangeset = function(){
    return changeset.value
  };
  
  var classList;
  this.toggleInputs = function(){
    var rows = fileList.querySelectorAll('tbody tr');
    for(i=0; i<rows.length; i++){
      classList = rows[i].classList
      if (classList.contains("selectable")){
        if (classList.contains("selected")) classList.remove("selected");
        else classList.add("selected");
      };
    };
  };

  fileList.querySelector("tbody").addEventListener("click", function(e){
    var tr = e.target.closest("tr");
    if (tr){
      classList = tr.classList;
      if (classList.contains("selectable")){
        if (classList.contains("selected")) classList.remove("selected");
        else classList.add("selected");
      };
    };
  });

  fileList.querySelector("th > input").addEventListener("click", function(e){
    var rows = fileList.querySelectorAll('tbody tr.selectable');
    var action = this.checked ? function(tr){ tr.classList.add("selected") } : function(tr){ tr.classList.remove("selected") };
    for(i=0; i<rows.length; i++) action(rows[i]);
  });

  function draw(files){
    
    var tr;
    tbody.innerHTML = "";
    for(i=0;i<files.length;i++){
      tr = tbody.insertRow(-1);
      if (files[i]["type"] == "file" && !files[i]["action"].includes("удалить") ){
        tr.classList.add("selected");
        tr.classList.add("selectable");
      }
      tr.setAttribute("file-index", files[i]["index"])
      tr.insertCell(-1);
      tr.insertCell(-1).innerHTML = files[i]["changeset"];
      tr.insertCell(-1).innerHTML = files[i]["item_folder"];
      tr.insertCell(-1).innerHTML = files[i]["item_name"];
      tr.insertCell(-1).innerHTML = formatDate(new Date(files[i]["date"]));
      tr.insertCell(-1).innerHTML = files[i]["action"];
    };
    if (files.length){
      labelFilesButton.disabled = false;
    } else {
      labelFilesButton.disabled = true;
    };
  };
  
  this.filesToLabel = function(){
    var filesToLabel=[], i;
    var rows = tbody.querySelectorAll('.selected');
    for(i=0; i<rows.length; i++){
       filesToLabel.push(fileAccount[rows[i].getAttribute("file-index")]);
    } 
    return filesToLabel
  };
  this.getLabel = function(){
    return label.value;
  };
  
  function createElement(params){
    var elem = document.createElement(params.type);
    elem.textContent = params.text;
    params.parent.appendChild(elem);    
  }
}


function Model(){
  
  var view, i;
  this.view = function(v){ view = v };
  
  var fileAccount = {};
  this.getFiles = function(version){
    
    if (!this.checkVersion(version)) throw "No version nor label name specified!";
    
    new Ajax({
      method: "GET",
      url: "get-files?version="+version
    })
    .success(function(xhr){
      JSON.parse(xhr.responseText).forEach(function(file){
        var key = file["item"] + "-" + file["changeset"];
        fileAccount[key] = file;
      })
      view.notify();
    })
    .fail(function(xhr){
      error(xhr);
      alert( xhr.status + ': ' + xhr.statusText + '\n' + xhr.responseText );
    })
    .done( function(){
      
    })
    .send();
  }

  this.getFileList = function(){
    var files = [];
    var keys = Object.keys(fileAccount);
    for(i=0; i<keys.length; i++){
      files.push( fileAccount[keys[i]] );
    }
    return files
  }
  this.deleteFiles = function(){
    fileAccount = {};
    view.notify();
  }
  
  this.labelFiles = function(files, label){
    if (!this.checkFilesToLabel(files)) throw "File list must not be empty!";
    if (!this.checkLabel(label)) throw "Label must not be empty!";

    new Ajax({
      method: "POST",
      url: "label-files",
      body: JSON.stringify([
          label, files.map( function(file){
            return {"item": file["item"], "changeset": file["changeset"], "comment": file["comment"]}
          })          
      ]),
      contentType: 'application/json; charset=utf-8'
    })
    .success(function(xhr){
      logger.info( "Files were labeled successfully." );
      var message = {}
      message["Label " + label] = files.map( function(file){ return file["item"] });
      console.log(message);
      logger.info(message);
    })
    .fail(function(xhr){
      throw "Failed to label files!" + xhr.responseText;
    })
    .send();
    
  }
  this.checkVersion = function(version){
    return !!version
  }
  
  this.checkFilesToLabel = function(files){
    return !!(files && files.length)
  }
  this.checkLabel = function(label){
    return !!label
  }
  
  function Ajax(params){
    var onsuccess, onfail, ondone;
        
    this.send = function(){
      var xhr = new XMLHttpRequest();
      
      xhr.open(params.method || "GET", params.url, true);
      xhr.setRequestHeader('Content-Type', params.contentType || 'application/x-www-form-urlencoded');
      xhr.send(params.body);
      xhr.onreadystatechange = function(){
        if (xhr.readyState != 4) return;
        
        if (xhr.status != 200) {
            if (onfail) onfail(xhr);
            if (ondone) ondone(xhr);
        } else {
            if (onsuccess) onsuccess(xhr);
            if (ondone) ondone(xhr);
        }
      }
    };
    this.success = function(callback){
      onsuccess = callback;
      return this
    };
    
    this.fail = function(callback){
      onfail = callback;
      return this
    };
    
    this.done = function(callback){
      ondone = callback;
      return this
    };
  }
  
}

function Controller(model,view){
  var tr, input, controls;
  document.addEventListener("click", function(e){
    try{
      
      if (e.target.tagName == "BUTTON" && e.target.disabled === false ){
          var action = e.target.getAttribute("action");
          if (action){
            switch(action){
              case "clear-all": 
                model.deleteFiles(); 
                break;
              case "get-files": 
                var version = view.getChangeset();
                model.getFiles(version); 
                break;
              case "label-files": 
                var files = view.filesToLabel();
                var label = view.getLabel();
                model.labelFiles(files, label); 
                break;
            };
          };
      }

    } catch(e) {
        alert(e)
    };
  })
  
  document.addEventListener("keypress", function(e){
      if (e.target.tagName == "INPUT" && e.charCode == 13 && (controls = e.target.closest(".controls"))){
          controls.querySelector("button").click();
      }
  })
}

var model = new Model;
var view = new View(model);
var ctrl = new Controller(model,view);
model.view(view);
