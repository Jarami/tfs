STDOUT.set_encoding(Encoding::IBM866, Encoding::UTF_8)

require 'net/http'
require 'uri'

folder = File.absolute_path( File.dirname(__FILE__) )

requests = [
  { method: "GET",  uri: "http://localhost:9292/changeset/41234",  test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } } ,
  { method: "GET",  uri: "http://localhost:9292/labels/vivsd_driver_15",  test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } } ,
  # { method: "POST", uri: "http://localhost:9292/label/vivsd_driver_15", body: 'files={"мой скрипт.rb":123,"another_script.rb":456}', test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } } ,
]

http = Net::HTTP.new("localhost", 9292)      
http.open_timeout = 10
http.read_timeout = 10

responses = []

begin

  http.start

  requests.each do |request|
    uri = URI(request[:uri])

    case request[:method]
    when "GET"
      req = Net::HTTP::Get.new(uri.request_uri)
    when "POST"
      req = Net::HTTP::Post.new(uri.request_uri)
      req.body = request[:body]
    end

    resp = http.request(req)
    
    puts request[:uri]
    puts "Status: " + resp.code
    puts "Message: " + resp.message
    puts "Headers: " + Hash[ resp.each.map{|k,v| [k,v] } ].to_s
    puts "Body:"
    puts resp.body 
    puts '======================================================'
    
    responses << { resp: resp, uri: request[:uri] }
    
    # if message = request[:test].call(resp)
    #   STDOUT.write "F"
    #   responses.last.merge!( message: message, fail: true )
    # else 
    #   STDOUT.write "."
    # end 
    
  end 
  
ensure 
  http.finish 
end 

# puts
# puts

# responses.each do |response|
#   if response[:fail]
#     puts response[:uri]
#     puts response[:message]
#     puts response[:resp].body
#     puts 
#   end 
# end 