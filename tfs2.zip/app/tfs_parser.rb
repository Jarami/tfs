require_relative 'ext'

class TfsParser

    MONTHS = {"января"=>1, "февраля"=>2, "марта"=>3, "апреля"=>4, "мая"=>5, "июня"=>6, "июля"=>7, "августа"=>8, "сентября"=>9, "октября"=>10, "ноября"=>11, "декабря"=>12}
    
    def initialize options = {}
    end 

    def changeset text, params = {}
    
      data = {}
      mode = nil
      StringIO.open(text) do |io|
        while !io.eof?
          line = io.readline.strip

          if line =~ /^Набор изменений: (\d+)/
            data[:commit] = $1.strip.to_i
          elsif line =~ /^Пользователь: (.+)/
            data[:user] = $1.strip
          elsif line =~ /Дата: (\d+) (января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря) (\d+) г. (\d+):(\d+):(\d+)/
            data[:date] = Time.mktime($3, MONTHS[$2], $1, $4, $5, $6).to_ms
          elsif line.start_with? "Примечание:"
            mode = :comment 
          elsif line.start_with? "Элементы:"
            mode = :items 
          elsif line.empty?

          else

            case mode 
              when :comment 
                data[:comment] ||= ""
                data[:comment] << line.strip << "\n"
              when :items 
                action, item = line.split("$").map(&:strip)
                data[:items] ||= []
                data[:items] << { action: action, item: "$" + item }
            end 
          end 
        end 
      end 

      data[:items] = data[:items].map do |item| 
        { 
          fullname: item[:item], 
          type:     File.extname(item[:item].gsub(/\;X\d+$/,"")).empty? ? "folder" : "file", 
          folder:   File.dirname(item[:item]),
          name:     File.basename(item[:item]),
          action:   item[:action],
        }
      end 

      data
        
    end 

    def labels text, params = {}
    
      data = [] 

      chunk_data = { comment: "", items: [] }
      StringIO.open(text, "r:utf-8") do |io| 
      
        mode, changeset_index, item_index = nil, nil, nil 
            
        while !io.eof? 
          line = io.readline
          
          if line =~ /Метка     : (.+)/    then chunk_data[:label] = $1
          elsif line =~ /Область   : (.+)/ then chunk_data[:collection] = $1
          elsif line =~ /Владелец  : (.+)/ then chunk_data[:owner] = $1
          elsif line =~ /Дата      : (\d+) (января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря) (\d+) г. (\d+):(\d+):(\d+)/ 
            chunk_data[:date] = Time.mktime($3, MONTHS[$2], $1, $4, $5, $6).to_ms
          elsif line =~ /Примечание: (.+)/
            mode = :comment 
            chunk_data[:comment] << $1
            
          elsif line =~ /^Набор изменений\s+Элемент/
            changeset_index = line.index("Набор изменений")
            item_index = line.index("Элемент")
            mode = :items
          
          elsif line.chomp == "==============================================================================="
            data << chunk_data
            mode = nil
            chunk_data = { comment: "", items: [] }
            
          else 
            
            case mode 
              when :comment 
                chunk_data[:comment] << line
              when :items 
                chunk_data[:items] << { commit: line[changeset_index...item_index].strip, item: line[item_index..-1].strip } if line =~ /^\d+/
            end 
            
          end 
        end 
      end 
      
      data << chunk_data if chunk_data[:label]
 
      files = []
      data.each do |chunk|
        chunk[:items].each do |item|
          files << { 
            item:        item[:item], 
            type:        File.extname(item[:item].gsub(/\;X\d+$/,"")).empty? ? "folder" : "file", 
            item_folder: File.dirname(item[:item]),
            item_name:   File.basename(item[:item]),
            changeset:   item[:commit],
            date:        nil,
            comment:     nil,
            action:      nil,
          }
        end 
      end 
      files
      
    end 
end 