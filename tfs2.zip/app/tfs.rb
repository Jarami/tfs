require 'monitor'
require 'erb'
require 'iconv'
require 'stringio'

class TFS

  COMMANDS = {
    :changeset => "changeset %{commit} /noprompt",
    :labels    => "labels %{label} /format:detailed /noprompt",
    :label     => "label %{label} %{files} /version:%{commit}",
    :label2    => "label %{label} %{files} /version:%{commit} /comment:%{comment}",
  }

  DEFUALTS = {
    tfs_path:          "C:/Program Files (x86)/Microsoft Visual Studio 11.0/Common7/IDE/tf.exe",
    working_directory: Dir.pwd
  }

  def initialize options = {}
    super()
    @tfs_directory     = File.absolute_path( options[:tfs_path]          || DEFUALTS[:tfs_path]     )
    @working_directory = File.absolute_path( options[:working_directory] || DEFUALTS[:working_directory] )

    @lock = Monitor.new
  end 

  def command_text command_type
    @tfs_directory.inspect + " " + COMMANDS[command_type]
  end 

  def changeset commit, options = {}
    execute( command_text(:changeset) % {commit: commit} )
  end 

  def labels label_name, options = {}
    execute( command_text(:labels) % {label: label_name} )
  end 

  def label label_name, options

    files = {}
    options[:files].each do |file, commit|
      files[commit] ||= []
      files[commit] << file 
    end 
    response = nil
    files.each.with_index do |(commit, commit_files), index|
      if options[:comment] && index == 0 
        # response << COMMANDS[:label2] % {label: label_name, commit: commit, files: commit_files.map{|f| '"%s"' % f}.join(" "), comment: options[:comment].inspect } 
        response = execute( COMMANDS[:label2] % {label: label_name, commit: commit, files: commit_files.map{|f| '"%s"' % f}.join(" "), comment: '"' + options[:comment] + '"' } )
      else 
        # response << COMMANDS[:label] % {label: label_name, commit: commit, files: commit_files.map{|f| '"%s"' % f}.join(" ") }
        response = execute( COMMANDS[:label] % {label: label_name, commit: commit, files: commit_files.map{|f| '"%s"' % f}.join(" ") } )
      end 
    end 
    # puts response.inspect
    response
  end 

  def execute text
    response = ""
    @lock.synchronize do 
      Dir.chdir(@working_directory) do 
        open("| #{text}") do |pipe|
          until pipe.eof?
            response << pipe.readline
          end
        end
      end 
    end
    # IBM866
    puts text
    [from_win(response), response]
  end 

  def from_win text
    Iconv.iconv('utf-8', 'windows-1251', text)[0]
  rescue => err
    puts "error: " + err.message
    text
  end 

end 
