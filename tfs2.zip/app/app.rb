STDOUT.set_encoding(Encoding::IBM866, Encoding::UTF_8)

require 'time'
require 'cgi'
require 'json'

require_relative 'ext'
require_relative 'logger'

require_relative 'tfs'
require_relative 'tfs_parser'

class App

  include Logger

  attr_reader :tfs, :tfs_parser 
  def initialize options = {}
    @tfs = TFS.new(options)
    @tfs_parser = TfsParser.new(options)

    @log_file = options[:log_to]
    File.open( @log_file, "w" ){|f| } if @log_file
  end 

  def call env 

    
    meth, args = parse_request(env)

    raise "No method found for #{meth}" unless tfs.respond_to?(meth)

    response = tfs.send(meth, *args)
    if response && !response.empty?
      response = tfs_parser.send(meth, response)
    else 
      raise RuntimeError, "Bad response from TFS"
    end 

    if response.is_a?(String)
      Rack::Response.new( response, 200, {"Content-Type"=>"text/plain; charset=utf-8"} )

    elsif response.is_a?(Hash) || response.is_a?(Array)
      Rack::Response.new( JSON.generate(response), 200, {"Content-Type"=>"application/json; charset=utf-8"} )

    else 
      raise "unknown response type"

    end 

  rescue Exception => ex 
    error(ex.message + "\n" + ex.backtrace.map{|s| "\t" + s }.join("\n") + "\nwith env:\n" + env.map{|k,v| "\t%s => %s" % [k,v]}.join("\n")) 
    exception_response ex 
  end 

  private 

  def parse_request env 
    args = env["PATH_INFO"].scan(/\/\w+/).map{|chunk| chunk[1..-1]}
    params = {}
    CGI::parse(env["QUERY_STRING"]).each do |k,v|
      params[k.to_sym] = v.first
    end 
    CGI::parse(env["rack.input"].read).each do |k,v|
      params[k.to_sym] = JSON.parse(v.first) rescue v.first
    end 
    args << params
    meth = args.shift

    return [meth, args]
  end 

  def exception_response ex 
    message = ex.message + "\n" + ex.backtrace.map{|line| "\t" + line }.join("\n")
    Rack::Response.new( 
      [], 
      500, 
      {"Content-Type"=>"text/plain"} 
    )
  end 

  def bad_response 
    Rack::Response.new( "Bad Request", 400 )
  end 
end 
