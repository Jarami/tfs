module Logger 
  TIME_FORMAT = "%F %T.%3N"
  LOG_FORMAT = "%s [%s] %s"
  def log level, message 
    log_message = LOG_FORMAT % [ Time.now.strftime(TIME_FORMAT), level.to_s.upcase, message ]
    if @log_file
      File.open( @log_file, "a+" ){|f| f.puts log_message }
    else
      STDOUT.puts( log_message )
    end 
  end 
  
  [:trace, :debug, :info, :warn, :error, :fatal].each do |m|
    define_method m do |message|
      log(__method__, message)
    end 
  end 
end 