# routes.rb

[
  { method: "GET",  path: "/",          controller: "TFS#index"     },
  { method: "GET",  path: "/labels",    controller: "TFS#labels"    },
  { method: "GET",  path: "/changeset", controller: "TFS#changeset" },

  { method: "POST", path: "/label",     controller: "TFS#label"     }, 
]